package com.example.model

enum class ViewMode {
    LIST,
    GRID
}
