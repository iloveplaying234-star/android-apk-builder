package com.example.model

data class CategoryCounts(
    val downloadsCount: Int = 0,
    val projectsCount: Int = 0,
    val picturesCount: Int = 0,
    val documentsCount: Int = 0
)
