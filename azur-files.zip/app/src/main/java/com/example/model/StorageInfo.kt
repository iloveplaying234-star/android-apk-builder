package com.example.model

data class StorageInfo(
    val totalBytes: Long = 128_000_000_000L,
    val usedBytes: Long = 64_500_000_000L,
    val freeBytes: Long = 63_500_000_000L
) {
    val usedPercentage: Float
        get() = if (totalBytes > 0) (usedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
}
