package com.example.model

enum class SortOrder(val titleFarsi: String) {
    NAME_ASC("نام (A-Z)"),
    NAME_DESC("نام (Z-A)"),
    DATE_NEWEST("جدیدترین"),
    DATE_OLDEST("قدیمی‌ترین"),
    SIZE_LARGEST("بزرگ‌ترین"),
    SIZE_SMALLEST("کوچک‌ترین")
}
