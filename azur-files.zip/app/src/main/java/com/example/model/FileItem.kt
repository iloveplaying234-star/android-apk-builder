package com.example.model

data class FileItem(
    val id: String,
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val size: Long = 0L,
    val lastModified: Long = System.currentTimeMillis(),
    val extension: String = "",
    val itemCount: Int = 0,
    val isFavorite: Boolean = false,
    val isDemo: Boolean = false
) {
    val isTextOrCodeFile: Boolean
        get() = !isDirectory && (
            extension.equals("txt", ignoreCase = true) ||
            extension.equals("json", ignoreCase = true) ||
            extension.equals("md", ignoreCase = true) ||
            extension.equals("kt", ignoreCase = true) ||
            extension.equals("java", ignoreCase = true) ||
            extension.equals("xml", ignoreCase = true) ||
            extension.equals("html", ignoreCase = true) ||
            extension.equals("css", ignoreCase = true) ||
            extension.equals("js", ignoreCase = true) ||
            extension.equals("ts", ignoreCase = true) ||
            extension.equals("py", ignoreCase = true) ||
            extension.equals("sh", ignoreCase = true) ||
            extension.equals("c", ignoreCase = true) ||
            extension.equals("cpp", ignoreCase = true) ||
            extension.equals("go", ignoreCase = true) ||
            extension.equals("rs", ignoreCase = true) ||
            extension.equals("php", ignoreCase = true) ||
            extension.equals("sql", ignoreCase = true) ||
            extension.equals("yaml", ignoreCase = true) ||
            extension.equals("csv", ignoreCase = true) ||
            extension.equals("conf", ignoreCase = true) ||
            extension.equals("log", ignoreCase = true) ||
            extension.equals("properties", ignoreCase = true) ||
            extension.equals("gradle", ignoreCase = true)
        )
}
