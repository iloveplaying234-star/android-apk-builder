package com.example.utils

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

object SyntaxHighlightUtils {

    // Palette for Dark Editor Mode
    private val darkJsonKeyColor = Color(0xFF60A5FA)      // Soft Blue
    private val darkJsonStringColor = Color(0xFF34D399)   // Emerald Green
    private val darkJsonNumberColor = Color(0xFFFBBF24)   // Amber
    private val darkJsonBooleanColor = Color(0xFFF472B6)  // Pink
    private val darkJsonPunctColor = Color(0xFF9CA3AF)    // Gray

    private val darkMdHeaderColor = Color(0xFF93C5FD)     // Light Blue
    private val darkMdBoldColor = Color(0xFFFDE047)       // Yellow
    private val darkMdListColor = Color(0xFF38BDF8)       // Sky
    private val darkMdCodeColor = Color(0xFFC084FC)       // Purple

    // Palette for Light Editor Mode
    private val lightJsonKeyColor = Color(0xFF1D4ED8)     // Blue
    private val lightJsonStringColor = Color(0xFF047857)  // Green
    private val lightJsonNumberColor = Color(0xFFD97706)  // Orange
    private val lightJsonBooleanColor = Color(0xFFBE185D) // Magenta
    private val lightJsonPunctColor = Color(0xFF4B5563)   // Dark Gray

    private val lightMdHeaderColor = Color(0xFF1E40AF)    // Deep Blue
    private val lightMdBoldColor = Color(0xFFB45309)      // Brown/Gold
    private val lightMdListColor = Color(0xFF0284C7)      // Cyan
    private val lightMdCodeColor = Color(0xFF7E22CE)      // Dark Purple

    fun buildHighlightedText(
        text: String,
        extension: String,
        isDark: Boolean
    ): AnnotatedString {
        val ext = extension.lowercase()
        return when (ext) {
            "json" -> highlightJson(text, isDark)
            "md", "markdown" -> highlightMarkdown(text, isDark)
            else -> buildAnnotatedString { append(text) }
        }
    }

    private fun highlightJson(text: String, isDark: Boolean): AnnotatedString {
        val keyColor = if (isDark) darkJsonKeyColor else lightJsonKeyColor
        val stringColor = if (isDark) darkJsonStringColor else lightJsonStringColor
        val numberColor = if (isDark) darkJsonNumberColor else lightJsonNumberColor
        val boolColor = if (isDark) darkJsonBooleanColor else lightJsonBooleanColor
        val punctColor = if (isDark) darkJsonPunctColor else lightJsonPunctColor

        val jsonRegex = Regex("""("(\\u[a-fA-F0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?)|(\b(true|false|null)\b)|(-?\d+(\.\d+)?([eE][+-]?\d+)?)""")

        return buildAnnotatedString {
            append(text)

            jsonRegex.findAll(text).forEach { result ->
                val str = result.value
                val range = result.range
                val style = when {
                    str.endsWith(":") -> SpanStyle(color = keyColor, fontWeight = FontWeight.SemiBold)
                    str.startsWith("\"") -> SpanStyle(color = stringColor)
                    str == "true" || str == "false" || str == "null" -> SpanStyle(color = boolColor, fontWeight = FontWeight.Bold)
                    str.first().isDigit() || str.first() == '-' -> SpanStyle(color = numberColor)
                    else -> SpanStyle(color = punctColor)
                }
                addStyle(style, range.first, range.last + 1)
            }
        }
    }

    private fun highlightMarkdown(text: String, isDark: Boolean): AnnotatedString {
        val headerColor = if (isDark) darkMdHeaderColor else lightMdHeaderColor
        val boldColor = if (isDark) darkMdBoldColor else lightMdBoldColor
        val listColor = if (isDark) darkMdListColor else lightMdListColor
        val codeColor = if (isDark) darkMdCodeColor else lightMdCodeColor

        val headerRegex = Regex("""^(#{1,6}\s+.*)$""", RegexOption.MULTILINE)
        val boldRegex = Regex("""(\*\*.*?\*\*)""")
        val listRegex = Regex("""^(\s*[-*+]\s+.*)$""", RegexOption.MULTILINE)
        val codeRegex = Regex("""(`[^`]+`)""")

        return buildAnnotatedString {
            append(text)

            headerRegex.findAll(text).forEach {
                addStyle(SpanStyle(color = headerColor, fontWeight = FontWeight.Bold), it.range.first, it.range.last + 1)
            }
            boldRegex.findAll(text).forEach {
                addStyle(SpanStyle(color = boldColor, fontWeight = FontWeight.Bold), it.range.first, it.range.last + 1)
            }
            listRegex.findAll(text).forEach {
                addStyle(SpanStyle(color = listColor), it.range.first, it.range.last + 1)
            }
            codeRegex.findAll(text).forEach {
                addStyle(SpanStyle(color = codeColor, fontFamily = FontFamily.Monospace), it.range.first, it.range.last + 1)
            }
        }
    }
}
