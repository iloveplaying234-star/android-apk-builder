package com.example.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FileFormatUtils {

    fun toPersianDigits(text: String): String {
        return text
            .replace('0', '۰')
            .replace('1', '۱')
            .replace('2', '۲')
            .replace('3', '۳')
            .replace('4', '۴')
            .replace('5', '۵')
            .replace('6', '۶')
            .replace('7', '۷')
            .replace('8', '۸')
            .replace('9', '۹')
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return toPersianDigits("0 B")
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
        val value = bytes / Math.pow(1024.0, digitGroups.toDouble())
        val formatted = if (digitGroups == 0) {
            "${value.toInt()} ${units[digitGroups]}"
        } else {
            String.format(Locale.US, "%.1f %s", value, units[digitGroups])
        }
        return toPersianDigits(formatted)
    }

    fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("yyyy/MM/dd | HH:mm", Locale.getDefault())
        val formatted = sdf.format(Date(timestamp))
        return toPersianDigits(formatted)
    }

    fun getRelativeTimeString(timestamp: Long): String {
        val now = System.currentTimeMillis()
        val diffMinutes = (now - timestamp) / (1000 * 60)
        return when {
            diffMinutes < 1 -> "همین الان"
            diffMinutes < 60 -> toPersianDigits("$diffMinutes دقیقه پیش")
            diffMinutes < 1440 -> toPersianDigits("${diffMinutes / 60} ساعت پیش")
            else -> toPersianDigits("${diffMinutes / 1440} روز پیش")
        }
    }
}
