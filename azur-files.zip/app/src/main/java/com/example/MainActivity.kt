package com.example

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.model.FileItem
import com.example.model.SortOrder
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.AzurFilesTheme
import com.example.viewmodel.EditorViewModel
import com.example.viewmodel.MainViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels()
    private val editorViewModel: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            var isDarkTheme by remember { mutableStateOf(true) }

            AzurFilesTheme(darkTheme = isDarkTheme) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AzurFilesApp(
                        mainViewModel = mainViewModel,
                        editorViewModel = editorViewModel,
                        isDarkTheme = isDarkTheme,
                        onToggleTheme = { isDarkTheme = it },
                        onShareFile = { fileItem -> shareFile(fileItem) },
                        onRequestPermissions = { requestStoragePermission() }
                    )
                }
            }
        }
    }

    private fun shareFile(fileItem: FileItem) {
        try {
            val file = File(fileItem.path)
            if (!file.exists()) {
                Toast.makeText(this, "فایل وجود ندارد", Toast.LENGTH_SHORT).show()
                return
            }
            val uri: Uri = FileProvider.getUriForFile(
                this,
                "${applicationContext.packageName}.fileprovider",
                file
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "اشتراک‌گذاری فایل"))
        } catch (e: Exception) {
            Toast.makeText(this, "امکان اشتراک‌گذاری نیست: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                    startActivity(intent)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AzurFilesApp(
    mainViewModel: MainViewModel,
    editorViewModel: EditorViewModel,
    isDarkTheme: Boolean,
    onToggleTheme: (Boolean) -> Unit,
    onShareFile: (FileItem) -> Unit,
    onRequestPermissions: () -> Unit
) {
    val context = LocalContext.current
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var currentScreen by remember { mutableStateOf("home") }
    var activeEditingFile by remember { mutableStateOf<FileItem?>(null) }

    var showCreateDialog by remember { mutableStateOf(false) }
    var renamingFile by remember { mutableStateOf<FileItem?>(null) }
    var showSearchSheet by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }

    val currentPath by mainViewModel.currentPath.collectAsState()
    val viewMode by mainViewModel.viewMode.collectAsState()
    val sortOrder by mainViewModel.sortOrder.collectAsState()
    val searchQuery by mainViewModel.searchQuery.collectAsState()
    val searchResults by mainViewModel.searchResults.collectAsState()
    val isZipping by mainViewModel.isZipping.collectAsState()
    val zipProgress by mainViewModel.zipProgress.collectAsState()

    // Listen to ViewModel message events
    LaunchedEffect(Unit) {
        mainViewModel.userMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // Permission Request Launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    LaunchedEffect(Unit) {
        onRequestPermissions()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
            )
        }
    }

    // Zip Progress Overlay
    if (isZipping) {
        ZipProgressDialog(
            progress = zipProgress,
            onDismiss = {}
        )
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            AzurDrawerContent(
                selectedRoute = currentScreen,
                onNavigate = { route ->
                    if (activeEditingFile != null) activeEditingFile = null
                    currentScreen = route
                },
                isDarkTheme = isDarkTheme,
                onToggleTheme = onToggleTheme,
                onCloseDrawer = { scope.launch { drawerState.close() } }
            )
        }
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                if (activeEditingFile == null) {
                    AzurTopBar(
                        title = when (currentScreen) {
                            "home" -> "فایلکس (Filex)"
                            "files" -> "فایل‌های من"
                            "gallery" -> "گالری رسانه"
                            "favorites" -> "علاقه‌مندی‌ها"
                            "hidden" -> "فایل‌های مخفی"
                            "cloud" -> "ذخیره‌سازی ابری"
                            "tools" -> "ابزارها"
                            "settings" -> "تنظیمات"
                            else -> "فایلکس (Filex)"
                        },
                        canNavigateBack = currentScreen == "files" && currentPath != mainViewModel.repositoryManager.getRootPath(),
                        onNavigateBack = { mainViewModel.navigateUp() },
                        onOpenDrawer = { scope.launch { drawerState.open() } },
                        viewMode = viewMode,
                        onToggleViewMode = { mainViewModel.toggleViewMode() },
                        onOpenSearch = { showSearchSheet = true },
                        onOpenSortMenu = { showSortMenu = true }
                    )
                }
            },
            bottomBar = {
                if (activeEditingFile == null) {
                    AzurBottomBar(
                        currentScreen = currentScreen,
                        onNavigate = { route ->
                            currentScreen = route
                        },
                        onCreateNewClick = { showCreateDialog = true }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (activeEditingFile != null) {
                    // Open Code/Text Editor
                    EditorScreen(
                        viewModel = editorViewModel,
                        isDarkTheme = isDarkTheme,
                        onNavigateBack = { activeEditingFile = null }
                    )
                } else {
                    when (currentScreen) {
                        "home" -> HomeScreen(
                            viewModel = mainViewModel,
                            onNavigateToFiles = { path ->
                                mainViewModel.navigateToDirectory(path)
                                currentScreen = "files"
                            },
                            onOpenFileInEditor = { item ->
                                editorViewModel.loadFile(mainViewModel.repositoryManager, item)
                                activeEditingFile = item
                            },
                            onOpenSearch = { showSearchSheet = true }
                        )

                        "files" -> FilesScreen(
                            viewModel = mainViewModel,
                            onOpenFileInEditor = { item ->
                                editorViewModel.loadFile(mainViewModel.repositoryManager, item)
                                activeEditingFile = item
                            },
                            onShareFile = onShareFile,
                            onOpenRenameDialog = { renamingFile = it }
                        )

                        "gallery" -> GalleryScreen(
                            viewModel = mainViewModel,
                            onNavigateBack = { currentScreen = "home" }
                        )

                        "favorites", "hidden", "cloud" -> {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "بخش ${when(currentScreen) { "favorites" -> "علاقه‌مندی‌ها"; "hidden" -> "فایل‌های مخفی"; else -> "ذخیره‌سازی ابری" }} فعال است",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        "tools" -> ToolsScreen(
                            viewModel = mainViewModel,
                            onOpenSearch = { showSearchSheet = true },
                            onNavigateToGallery = { currentScreen = "gallery" },
                            onShowMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }
                        )

                        "settings" -> SettingsScreen(
                            viewModel = mainViewModel,
                            isDarkTheme = isDarkTheme,
                            onToggleTheme = onToggleTheme,
                            onShowMessage = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }
                        )
                    }
                }
            }
        }
    }

    // Create Dialog
    if (showCreateDialog) {
        CreateFileDialog(
            onDismiss = { showCreateDialog = false },
            onCreateFile = { name, content -> mainViewModel.createFile(name, content) },
            onCreateFolder = { name -> mainViewModel.createDirectory(name) }
        )
    }

    // Rename Dialog
    renamingFile?.let { item ->
        RenameFileDialog(
            item = item,
            onDismiss = { renamingFile = null },
            onConfirmRename = { newName -> mainViewModel.renameFile(item.path, newName) }
        )
    }

    // Sort Order Menu Sheet
    if (showSortMenu) {
        AlertDialog(
            onDismissRequest = { showSortMenu = false },
            confirmButton = {},
            title = { Text("مرتب‌سازی فایل‌ها", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    SortOrder.values().forEach { order ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = sortOrder == order,
                                onClick = {
                                    mainViewModel.setSortOrder(order)
                                    showSortMenu = false
                                }
                            )
                            Text(
                                text = order.titleFarsi,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    // Search Sheet
    if (showSearchSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSearchSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .heightIn(max = 500.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { mainViewModel.setSearchQuery(it) },
                    placeholder = { Text("نام فایل یا پوشه را وارد کنید...") },
                    leadingIcon = { Icon(imageVector = Icons.Outlined.Search, contentDescription = null) },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (searchResults.isEmpty() && searchQuery.isNotBlank()) {
                    Text(
                        text = "هیچ فایلی یافت نشد",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth()) {
                        items(searchResults) { item ->
                            FileItemRow(
                                item = item,
                                onClick = {
                                    showSearchSheet = false
                                    if (item.isTextOrCodeFile) {
                                        editorViewModel.loadFile(mainViewModel.repositoryManager, item)
                                        activeEditingFile = item
                                    } else if (item.isDirectory) {
                                        mainViewModel.navigateToDirectory(item.path)
                                        currentScreen = "files"
                                    }
                                },
                                onFavoriteToggle = { mainViewModel.toggleFavorite(item.path) },
                                onMenuClick = {}
                            )
                        }
                    }
                }
            }
        }
    }
}
