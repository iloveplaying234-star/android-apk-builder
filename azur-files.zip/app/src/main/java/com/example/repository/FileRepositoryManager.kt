package com.example.repository

import android.content.Context
import com.example.model.FileItem
import com.example.model.SortOrder
import com.example.model.StorageInfo

class FileRepositoryManager(context: Context) : FileRepository {

    private val realRepository = RealFileRepository(context)

    override fun getRootPath(): String = realRepository.getRootPath()

    override suspend fun getFiles(directoryPath: String, sortOrder: SortOrder): List<FileItem> {
        return realRepository.getFiles(directoryPath, sortOrder)
    }

    override suspend fun getStorageInfo(): StorageInfo {
        return realRepository.getStorageInfo()
    }

    override suspend fun getCategoryCounts(): com.example.model.CategoryCounts {
        return realRepository.getCategoryCounts()
    }

    override suspend fun createFile(parentPath: String, fileName: String, content: String): Result<FileItem> {
        return realRepository.createFile(parentPath, fileName, content)
    }

    override suspend fun createDirectory(parentPath: String, dirName: String): Result<FileItem> {
        return realRepository.createDirectory(parentPath, dirName)
    }

    override suspend fun readFileContent(filePath: String): Result<String> {
        return realRepository.readFileContent(filePath)
    }

    override suspend fun writeFileContent(filePath: String, content: String): Result<Unit> {
        return realRepository.writeFileContent(filePath, content)
    }

    override suspend fun renameFile(filePath: String, newName: String): Result<FileItem> {
        return realRepository.renameFile(filePath, newName)
    }

    override suspend fun deleteFile(filePath: String): Result<Unit> {
        return realRepository.deleteFile(filePath)
    }

    override suspend fun searchFiles(query: String, startPath: String): List<FileItem> {
        return realRepository.searchFiles(query, startPath)
    }

    override suspend fun compressToZip(
        sourcePaths: List<String>,
        zipDestinationPath: String,
        onProgress: (Float) -> Unit
    ): Result<FileItem> {
        return realRepository.compressToZip(sourcePaths, zipDestinationPath, onProgress)
    }

    override suspend fun extractZip(
        zipFilePath: String,
        targetDirectoryPath: String,
        onProgress: (Float) -> Unit
    ): Result<FileItem> {
        return realRepository.extractZip(zipFilePath, targetDirectoryPath, onProgress)
    }
}
