package com.example.repository

import com.example.model.FileItem
import com.example.model.StorageInfo
import com.example.model.SortOrder

interface FileRepository {
    suspend fun getFiles(directoryPath: String, sortOrder: SortOrder = SortOrder.NAME_ASC): List<FileItem>
    suspend fun getStorageInfo(): StorageInfo
    suspend fun getCategoryCounts(): com.example.model.CategoryCounts
    suspend fun createFile(parentPath: String, fileName: String, content: String = ""): Result<FileItem>
    suspend fun createDirectory(parentPath: String, dirName: String): Result<FileItem>
    suspend fun readFileContent(filePath: String): Result<String>
    suspend fun writeFileContent(filePath: String, content: String): Result<Unit>
    suspend fun renameFile(filePath: String, newName: String): Result<FileItem>
    suspend fun deleteFile(filePath: String): Result<Unit>
    suspend fun searchFiles(query: String, startPath: String): List<FileItem>
    suspend fun compressToZip(sourcePaths: List<String>, zipDestinationPath: String, onProgress: (Float) -> Unit): Result<FileItem>
    suspend fun extractZip(zipFilePath: String, targetDirectoryPath: String, onProgress: (Float) -> Unit): Result<FileItem>
    fun getRootPath(): String
}
