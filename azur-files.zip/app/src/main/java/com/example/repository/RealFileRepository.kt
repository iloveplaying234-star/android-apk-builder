package com.example.repository

import android.content.Context
import android.os.Environment
import com.example.model.FileItem
import com.example.model.SortOrder
import com.example.model.StorageInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class RealFileRepository(private val context: Context) : FileRepository {

    override fun getRootPath(): String {
        val externalStorage = Environment.getExternalStorageDirectory()
        return if (externalStorage != null && externalStorage.canRead()) {
            externalStorage.absolutePath
        } else {
            context.filesDir.absolutePath
        }
    }

    override suspend fun getFiles(directoryPath: String, sortOrder: SortOrder): List<FileItem> = withContext(Dispatchers.IO) {
        val targetDir = File(directoryPath)
        if (!targetDir.exists() || !targetDir.isDirectory) return@withContext emptyList()

        val files = targetDir.listFiles() ?: return@withContext emptyList()

        val items = files.map { file ->
            val isDir = file.isDirectory
            val count = if (isDir) file.listFiles()?.size ?: 0 else 0
            val ext = if (!isDir) file.extension else ""
            FileItem(
                id = file.absolutePath,
                name = file.name,
                path = file.absolutePath,
                isDirectory = isDir,
                size = if (isDir) 0L else file.length(),
                lastModified = file.lastModified(),
                extension = ext,
                itemCount = count,
                isDemo = false
            )
        }

        return@withContext sortFiles(items, sortOrder)
    }

    private fun sortFiles(items: List<FileItem>, sortOrder: SortOrder): List<FileItem> {
        val (dirs, nonDirs) = items.partition { it.isDirectory }
        val sortedDirs = when (sortOrder) {
            SortOrder.NAME_ASC -> dirs.sortedBy { it.name.lowercase() }
            SortOrder.NAME_DESC -> dirs.sortedByDescending { it.name.lowercase() }
            SortOrder.DATE_NEWEST -> dirs.sortedByDescending { it.lastModified }
            SortOrder.DATE_OLDEST -> dirs.sortedBy { it.lastModified }
            SortOrder.SIZE_LARGEST -> dirs.sortedByDescending { it.itemCount }
            SortOrder.SIZE_SMALLEST -> dirs.sortedBy { it.itemCount }
        }
        val sortedFiles = when (sortOrder) {
            SortOrder.NAME_ASC -> nonDirs.sortedBy { it.name.lowercase() }
            SortOrder.NAME_DESC -> nonDirs.sortedByDescending { it.name.lowercase() }
            SortOrder.DATE_NEWEST -> nonDirs.sortedByDescending { it.lastModified }
            SortOrder.DATE_OLDEST -> nonDirs.sortedBy { it.lastModified }
            SortOrder.SIZE_LARGEST -> nonDirs.sortedByDescending { it.size }
            SortOrder.SIZE_SMALLEST -> nonDirs.sortedBy { it.size }
        }
        return sortedDirs + sortedFiles
    }

    override suspend fun getStorageInfo(): StorageInfo = withContext(Dispatchers.IO) {
        val root = Environment.getExternalStorageDirectory() ?: context.filesDir
        val total = root.totalSpace
        val free = root.freeSpace
        val used = total - free
        StorageInfo(
            totalBytes = if (total > 0) total else 128_000_000_000L,
            usedBytes = if (total > 0) used else 64_000_000_000L,
            freeBytes = if (total > 0) free else 64_000_000_000L
        )
    }

    override suspend fun getCategoryCounts(): com.example.model.CategoryCounts = withContext(Dispatchers.IO) {
        val rootPathStr = getRootPath()
        val root = File(rootPathStr)

        fun countInDir(dir: File): Int {
            return try {
                if (dir.exists() && dir.isDirectory) {
                    dir.listFiles()?.size ?: 0
                } else {
                    0
                }
            } catch (e: Exception) {
                0
            }
        }

        val dlDir1 = File(root, "Download")
        val dlDir2 = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val dlCount = maxOf(countInDir(dlDir1), if (dlDir2 != null) countInDir(dlDir2) else 0)

        val projDir = File(root, "Projects")
        val projCount = countInDir(projDir)

        val picDir1 = File(root, "Pictures")
        val picDir2 = File(root, "DCIM")
        val picCount = countInDir(picDir1) + countInDir(picDir2)

        val docDir = File(root, "Documents")
        val docCount = countInDir(docDir)

        com.example.model.CategoryCounts(
            downloadsCount = dlCount,
            projectsCount = projCount,
            picturesCount = picCount,
            documentsCount = docCount
        )
    }

    override suspend fun createFile(parentPath: String, fileName: String, content: String): Result<FileItem> = withContext(Dispatchers.IO) {
        try {
            val parentDir = File(parentPath)
            if (!parentDir.exists()) parentDir.mkdirs()

            val targetFile = File(parentDir, fileName)
            if (targetFile.exists()) {
                return@withContext Result.failure(Exception("فایلی با این نام قبلاً وجود دارد"))
            }

            val created = targetFile.createNewFile()
            if (!created) {
                return@withContext Result.failure(Exception("خطا در ایجاد فایل"))
            }

            if (content.isNotEmpty()) {
                targetFile.writeText(content, Charsets.UTF_8)
            }

            val item = FileItem(
                id = targetFile.absolutePath,
                name = targetFile.name,
                path = targetFile.absolutePath,
                isDirectory = false,
                size = targetFile.length(),
                lastModified = targetFile.lastModified(),
                extension = targetFile.extension,
                isDemo = false
            )
            Result.success(item)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun createDirectory(parentPath: String, dirName: String): Result<FileItem> = withContext(Dispatchers.IO) {
        try {
            val parentDir = File(parentPath)
            val newDir = File(parentDir, dirName)
            if (newDir.exists()) {
                return@withContext Result.failure(Exception("پوشه‌ای با این نام قبلاً وجود دارد"))
            }

            val success = newDir.mkdirs()
            if (!success) {
                return@withContext Result.failure(Exception("خطا در ساخت پوشه"))
            }

            val item = FileItem(
                id = newDir.absolutePath,
                name = newDir.name,
                path = newDir.absolutePath,
                isDirectory = true,
                size = 0L,
                lastModified = newDir.lastModified(),
                itemCount = 0,
                isDemo = false
            )
            Result.success(item)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun readFileContent(filePath: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)
            if (!file.exists()) return@withContext Result.failure(Exception("فایل یافت نشد"))
            val text = file.readText(Charsets.UTF_8)
            Result.success(text)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun writeFileContent(filePath: String, content: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)
            file.writeText(content, Charsets.UTF_8)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun renameFile(filePath: String, newName: String): Result<FileItem> = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)
            if (!file.exists()) return@withContext Result.failure(Exception("فایل وجود ندارد"))

            val destination = File(file.parentFile, newName)
            if (destination.exists()) return@withContext Result.failure(Exception("فایلی با این نام وجود دارد"))

            val renamed = file.renameTo(destination)
            if (!renamed) return@withContext Result.failure(Exception("امکان تغییر نام وجود ندارد"))

            val item = FileItem(
                id = destination.absolutePath,
                name = destination.name,
                path = destination.absolutePath,
                isDirectory = destination.isDirectory,
                size = if (destination.isDirectory) 0L else destination.length(),
                lastModified = destination.lastModified(),
                extension = destination.extension,
                itemCount = if (destination.isDirectory) destination.listFiles()?.size ?: 0 else 0,
                isDemo = false
            )
            Result.success(item)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteFile(filePath: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)
            if (!file.exists()) return@withContext Result.success(Unit)
            val deleted = if (file.isDirectory) file.deleteRecursively() else file.delete()
            if (deleted) Result.success(Unit) else Result.failure(Exception("خطا در حذف فایل"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun searchFiles(query: String, startPath: String): List<FileItem> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val results = mutableListOf<FileItem>()
        val startDir = File(startPath)

        fun searchRecursive(dir: File) {
            val list = dir.listFiles() ?: return
            for (f in list) {
                if (f.name.contains(query, ignoreCase = true)) {
                    val isDir = f.isDirectory
                    results.add(
                        FileItem(
                            id = f.absolutePath,
                            name = f.name,
                            path = f.absolutePath,
                            isDirectory = isDir,
                            size = if (isDir) 0L else f.length(),
                            lastModified = f.lastModified(),
                            extension = if (!isDir) f.extension else "",
                            itemCount = if (isDir) f.listFiles()?.size ?: 0 else 0,
                            isDemo = false
                        )
                    )
                }
                if (f.isDirectory && results.size < 50) {
                    searchRecursive(f)
                }
            }
        }

        searchRecursive(startDir)
        results
    }

    override suspend fun compressToZip(
        sourcePaths: List<String>,
        zipDestinationPath: String,
        onProgress: (Float) -> Unit
    ): Result<FileItem> = withContext(Dispatchers.IO) {
        try {
            val destFile = File(zipDestinationPath)
            if (destFile.exists()) destFile.delete()

            var totalBytes = 0L
            val filesToCompress = mutableListOf<Pair<File, String>>()

            fun collectFiles(f: File, baseDirName: String) {
                if (f.isDirectory) {
                    val children = f.listFiles() ?: return
                    for (child in children) {
                        collectFiles(child, "$baseDirName/${f.name}")
                    }
                } else {
                    totalBytes += f.length()
                    filesToCompress.add(f to "$baseDirName/${f.name}")
                }
            }

            for (path in sourcePaths) {
                val f = File(path)
                if (f.exists()) {
                    if (f.isDirectory) {
                        collectFiles(f, "")
                    } else {
                        totalBytes += f.length()
                        filesToCompress.add(f to f.name)
                    }
                }
            }

            val totalToCompress = if (totalBytes > 0) totalBytes else 1L
            var processedBytes = 0L

            FileOutputStream(destFile).use { fos ->
                BufferedOutputStream(fos).use { bos ->
                    ZipOutputStream(bos).use { zos ->
                        val buffer = ByteArray(8192)
                        for ((file, entryName) in filesToCompress) {
                            val cleanName = entryName.trimStart('/')
                            val zipEntry = ZipEntry(cleanName)
                            zos.putNextEntry(zipEntry)

                            FileInputStream(file).use { fis ->
                                var len: Int
                                while (fis.read(buffer).also { len = it } > 0) {
                                    zos.write(buffer, 0, len)
                                    processedBytes += len
                                    val progress = (processedBytes.toFloat() / totalToCompress).coerceIn(0f, 1f)
                                    withContext(Dispatchers.Main) { onProgress(progress) }
                                }
                            }
                            zos.closeEntry()
                        }
                    }
                }
            }

            withContext(Dispatchers.Main) { onProgress(1f) }

            val item = FileItem(
                id = destFile.absolutePath,
                name = destFile.name,
                path = destFile.absolutePath,
                isDirectory = false,
                size = destFile.length(),
                lastModified = destFile.lastModified(),
                extension = "zip"
            )
            Result.success(item)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun extractZip(
        zipFilePath: String,
        targetDirectoryPath: String,
        onProgress: (Float) -> Unit
    ): Result<FileItem> = withContext(Dispatchers.IO) {
        try {
            val zipFile = File(zipFilePath)
            if (!zipFile.exists()) return@withContext Result.failure(Exception("فایل ZIP یافت نشد"))

            val targetDir = File(targetDirectoryPath)
            if (!targetDir.exists()) targetDir.mkdirs()

            val totalBytes = zipFile.length()
            var extractedBytes = 0L

            ZipInputStream(FileInputStream(zipFile)).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                val buffer = ByteArray(8192)

                while (entry != null) {
                    val newFile = File(targetDir, entry.name)
                    if (entry.isDirectory) {
                        newFile.mkdirs()
                    } else {
                        newFile.parentFile?.mkdirs()
                        FileOutputStream(newFile).use { fos ->
                            var len: Int
                            while (zis.read(buffer).also { len = it } > 0) {
                                fos.write(buffer, 0, len)
                                extractedBytes += len
                                val progress = (extractedBytes.toFloat() / (totalBytes.coerceAtLeast(1L))).coerceIn(0f, 1f)
                                withContext(Dispatchers.Main) { onProgress(progress) }
                            }
                        }
                    }
                    entry = zis.nextEntry
                }
            }

            withContext(Dispatchers.Main) { onProgress(1f) }

            val dirItem = FileItem(
                id = targetDir.absolutePath,
                name = targetDir.name,
                path = targetDir.absolutePath,
                isDirectory = true,
                itemCount = targetDir.listFiles()?.size ?: 0
            )
            Result.success(dirItem)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
