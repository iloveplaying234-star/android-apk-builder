package com.example.viewmodel

import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.FileItem
import com.example.repository.FileRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class EditorViewModel : ViewModel() {

    private var fileRepository: FileRepository? = null

    private val _fileItem = MutableStateFlow<FileItem?>(null)
    val fileItem: StateFlow<FileItem?> = _fileItem.asStateFlow()

    private val _textContent = MutableStateFlow(TextFieldValue(""))
    val textContent: StateFlow<TextFieldValue> = _textContent.asStateFlow()

    private val _saveStatus = MutableStateFlow("ذخیره شده")
    val saveStatus: StateFlow<String> = _saveStatus.asStateFlow()

    private val _isMarkdownPreview = MutableStateFlow(false)
    val isMarkdownPreview: StateFlow<Boolean> = _isMarkdownPreview.asStateFlow()

    private val _userMessage = MutableSharedFlow<String>()
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    private val undoStack = mutableListOf<String>()
    private val redoStack = mutableListOf<String>()
    private var autoSaveJob: Job? = null

    fun loadFile(repository: FileRepository, item: FileItem) {
        this.fileRepository = repository
        _fileItem.value = item
        _isMarkdownPreview.value = false

        viewModelScope.launch {
            _saveStatus.value = "در حال بارگذاری..."
            val result = repository.readFileContent(item.path)
            result.onSuccess { content ->
                _textContent.value = TextFieldValue(content)
                _saveStatus.value = "ذخیره شده"
                undoStack.clear()
                redoStack.clear()
                undoStack.add(content)
            }.onFailure { err ->
                _saveStatus.value = "خطا در خواندن"
                _userMessage.emit("خطا در بارگذاری: ${err.message}")
            }
        }
    }

    fun onContentChange(newValue: TextFieldValue) {
        val oldText = _textContent.value.text
        _textContent.value = newValue

        if (newValue.text != oldText) {
            _saveStatus.value = "در حال ویرایش..."
            if (undoStack.isEmpty() || undoStack.last() != newValue.text) {
                undoStack.add(newValue.text)
                if (undoStack.size > 50) undoStack.removeAt(0)
                redoStack.clear()
            }
            triggerAutoSave()
        }
    }

    private fun triggerAutoSave() {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(1500) // Auto-save after 1.5 seconds of inactivity
            saveFile()
        }
    }

    fun saveFile() {
        val repo = fileRepository ?: return
        val file = _fileItem.value ?: return

        viewModelScope.launch {
            _saveStatus.value = "در حال ذخیره‌سازی..."
            val content = _textContent.value.text
            val result = repo.writeFileContent(file.path, content)
            result.onSuccess {
                _saveStatus.value = "ذخیره شده"
            }.onFailure { err ->
                _saveStatus.value = "خطا در ذخیره"
                _userMessage.emit("خطا در ذخیره فایل: ${err.message}")
            }
        }
    }

    fun undo() {
        if (undoStack.size > 1) {
            val current = undoStack.removeAt(undoStack.lastIndex)
            redoStack.add(current)
            val previous = undoStack.last()
            _textContent.value = TextFieldValue(previous)
            saveFile()
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.removeAt(redoStack.lastIndex)
            undoStack.add(next)
            _textContent.value = TextFieldValue(next)
            saveFile()
        }
    }

    fun insertTextAtSelection(prefix: String, suffix: String = "") {
        val value = _textContent.value
        val text = value.text
        val selection = value.selection

        val selectedText = text.substring(selection.start, selection.end)
        val replacement = prefix + selectedText + suffix
        val newText = text.substring(0, selection.start) + replacement + text.substring(selection.end)

        val newCursor = selection.start + prefix.length + selectedText.length
        onContentChange(TextFieldValue(newText, selection = androidx.compose.ui.text.TextRange(newCursor)))
    }

    fun toggleMarkdownPreview() {
        _isMarkdownPreview.value = !_isMarkdownPreview.value
    }
}
