package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.CategoryCounts
import com.example.model.FileItem
import com.example.model.SortOrder
import com.example.model.StorageInfo
import com.example.model.ViewMode
import com.example.repository.FileRepositoryManager
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repositoryManager = FileRepositoryManager(application)

    private val _currentPath = MutableStateFlow(repositoryManager.getRootPath())
    val currentPath: StateFlow<String> = _currentPath.asStateFlow()

    private val _files = MutableStateFlow<List<FileItem>>(emptyList())
    val files: StateFlow<List<FileItem>> = _files.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<FileItem>>(emptyList())
    val searchResults: StateFlow<List<FileItem>> = _searchResults.asStateFlow()

    private val _sortOrder = MutableStateFlow(SortOrder.NAME_ASC)
    val sortOrder: StateFlow<SortOrder> = _sortOrder.asStateFlow()

    private val _viewMode = MutableStateFlow(ViewMode.LIST)
    val viewMode: StateFlow<ViewMode> = _viewMode.asStateFlow()

    private val _storageInfo = MutableStateFlow(StorageInfo())
    val storageInfo: StateFlow<StorageInfo> = _storageInfo.asStateFlow()

    private val _categoryCounts = MutableStateFlow(CategoryCounts())
    val categoryCounts: StateFlow<CategoryCounts> = _categoryCounts.asStateFlow()

    private val _recentFiles = MutableStateFlow<List<FileItem>>(emptyList())
    val recentFiles: StateFlow<List<FileItem>> = _recentFiles.asStateFlow()

    private val _favoritePaths = MutableStateFlow<Set<String>>(emptySet())
    val favoritePaths: StateFlow<Set<String>> = _favoritePaths.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isZipping = MutableStateFlow(false)
    val isZipping: StateFlow<Boolean> = _isZipping.asStateFlow()

    private val _zipProgress = MutableStateFlow(0f)
    val zipProgress: StateFlow<Float> = _zipProgress.asStateFlow()

    private val _userMessage = MutableSharedFlow<String>()
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    init {
        refreshAll()
    }

    fun refreshAll() {
        loadDirectory(_currentPath.value)
        loadStorageInfo()
        loadRecentFiles()
        loadCategoryCounts()
    }

    private fun loadCategoryCounts() {
        viewModelScope.launch {
            try {
                _categoryCounts.value = repositoryManager.getCategoryCounts()
            } catch (_: Exception) {}
        }
    }

    fun loadDirectory(path: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _currentPath.value = path
            val list = repositoryManager.getFiles(path, _sortOrder.value)
            _files.value = list
            _isLoading.value = false
        }
    }

    private fun loadStorageInfo() {
        viewModelScope.launch {
            _storageInfo.value = repositoryManager.getStorageInfo()
        }
    }

    private fun loadRecentFiles() {
        viewModelScope.launch {
            val root = repositoryManager.getRootPath()
            val items = repositoryManager.getFiles(root, SortOrder.DATE_NEWEST)
                .filter { !it.isDirectory }
                .take(5)
            _recentFiles.value = items
        }
    }

    fun navigateToDirectory(path: String) {
        _searchQuery.value = ""
        _searchResults.value = emptyList()
        loadDirectory(path)
    }

    fun navigateUp(): Boolean {
        val root = repositoryManager.getRootPath()
        val current = _currentPath.value
        if (current == root || current.isEmpty()) return false

        val parent = current.substringBeforeLast('/', root)
        val targetParent = if (parent.isEmpty()) root else parent
        navigateToDirectory(targetParent)
        return true
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            return
        }
        viewModelScope.launch {
            val results = repositoryManager.searchFiles(query, _currentPath.value)
            _searchResults.value = results
        }
    }

    fun setSortOrder(order: SortOrder) {
        _sortOrder.value = order
        loadDirectory(_currentPath.value)
    }

    fun toggleViewMode() {
        _viewMode.value = if (_viewMode.value == ViewMode.LIST) ViewMode.GRID else ViewMode.LIST
    }

    fun createFile(fileName: String, initialContent: String = "") {
        viewModelScope.launch {
            val result = repositoryManager.createFile(_currentPath.value, fileName, initialContent)
            result.onSuccess { newFile ->
                _userMessage.emit("فایل «${newFile.name}» با موفقیت ساخته شد")
                refreshAll()
            }.onFailure { err ->
                _userMessage.emit("خطا: ${err.message}")
            }
        }
    }

    fun createDirectory(dirName: String) {
        viewModelScope.launch {
            val result = repositoryManager.createDirectory(_currentPath.value, dirName)
            result.onSuccess { newDir ->
                _userMessage.emit("پوشه «${newDir.name}» با موفقیت ساخته شد")
                refreshAll()
            }.onFailure { err ->
                _userMessage.emit("خطا: ${err.message}")
            }
        }
    }

    fun renameFile(filePath: String, newName: String) {
        viewModelScope.launch {
            val result = repositoryManager.renameFile(filePath, newName)
            result.onSuccess { updated ->
                _userMessage.emit("نام به «${updated.name}» تغییر یافت")
                refreshAll()
            }.onFailure { err ->
                _userMessage.emit("خطا: ${err.message}")
            }
        }
    }

    fun deleteFile(filePath: String) {
        viewModelScope.launch {
            val result = repositoryManager.deleteFile(filePath)
            result.onSuccess {
                _userMessage.emit("با موفقیت حذف شد")
                refreshAll()
            }.onFailure { err ->
                _userMessage.emit("خطا: ${err.message}")
            }
        }
    }

    fun toggleFavorite(path: String) {
        _favoritePaths.update { set ->
            if (set.contains(path)) set - path else set + path
        }
    }

    fun addToRecent(item: FileItem) {
        _recentFiles.update { current ->
            (listOf(item) + current.filter { it.path != item.path }).take(10)
        }
    }

    fun compressFiles(paths: List<String>, zipName: String) {
        viewModelScope.launch {
            _isZipping.value = true
            _zipProgress.value = 0f
            val destName = if (zipName.endsWith(".zip", ignoreCase = true)) zipName else "$zipName.zip"
            val destPath = "${_currentPath.value}/$destName"

            val res = repositoryManager.compressToZip(paths, destPath) { progress ->
                _zipProgress.value = progress
            }

            _isZipping.value = false
            res.onSuccess {
                _userMessage.emit("فایل ZIP با موفقیت ایجاد شد: $destName")
                refreshAll()
            }.onFailure { err ->
                _userMessage.emit("خطا در فشرده‌سازی: ${err.message}")
            }
        }
    }

    fun extractZip(zipFilePath: String, targetDirName: String = "") {
        viewModelScope.launch {
            _isZipping.value = true
            _zipProgress.value = 0f
            val baseName = zipFilePath.substringAfterLast('/').substringBeforeLast('.')
            val targetName = targetDirName.ifBlank { "${baseName}_extracted" }
            val destPath = "${_currentPath.value}/$targetName"

            val res = repositoryManager.extractZip(zipFilePath, destPath) { progress ->
                _zipProgress.value = progress
            }

            _isZipping.value = false
            res.onSuccess {
                _userMessage.emit("فایل با موفقیت استخراج شد در پوشه: $targetName")
                refreshAll()
            }.onFailure { err ->
                _userMessage.emit("خطا در استخراج ZIP: ${err.message}")
            }
        }
    }
}
