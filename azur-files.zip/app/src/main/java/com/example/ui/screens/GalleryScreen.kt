package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Audiotrack
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.FileItem
import com.example.ui.components.MediaViewerDialog
import com.example.utils.FileFormatUtils
import com.example.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Fast & Smooth Media Gallery Screen
 * Optimized for entry-level devices (Redmi 13C, etc.) with Dispatchers.IO background scanning
 * and target directory filtering.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    var selectedCategory by remember { mutableIntStateOf(0) } // 0: Images, 1: Videos, 2: Audio
    var selectedMediaItem by remember { mutableStateOf<FileItem?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    val rootPath = viewModel.repositoryManager.getRootPath()

    // Query media files safely on Dispatchers.IO without locking UI thread
    val mediaFiles by produceState<List<FileItem>>(initialValue = emptyList(), key1 = selectedCategory) {
        isLoading = true
        value = withContext(Dispatchers.IO) {
            val root = File(rootPath)
            val extList = when (selectedCategory) {
                0 -> setOf("jpg", "jpeg", "png", "webp", "bmp", "gif")
                1 -> setOf("mp4", "mkv", "webm", "avi", "3gp")
                else -> setOf("mp3", "wav", "aac", "flac", "m4a", "ogg")
            }

            // High-priority user media directories to avoid scanning android internal app caches
            val targetDirs = listOf(
                File(root, "DCIM"),
                File(root, "Pictures"),
                File(root, "Movies"),
                File(root, "Music"),
                File(root, "Download"),
                File(root, "Documents"),
                root
            ).filter { it.exists() && it.isDirectory }

            val results = mutableListOf<FileItem>()
            val visitedPaths = mutableSetOf<String>()

            fun scanDir(dir: File, depth: Int) {
                if (depth > 3 || !dir.exists() || !dir.isDirectory || dir.name.startsWith(".")) return
                if (!visitedPaths.add(dir.absolutePath)) return

                dir.listFiles()?.forEach { file ->
                    if (file.isDirectory) {
                        if (!file.name.startsWith(".") && file.name != "Android") {
                            scanDir(file, depth + 1)
                        }
                    } else if (file.isFile) {
                        val ext = file.extension.lowercase()
                        if (ext in extList) {
                            results.add(
                                FileItem(
                                    id = file.absolutePath,
                                    path = file.absolutePath,
                                    name = file.name,
                                    isDirectory = false,
                                    size = file.length(),
                                    lastModified = file.lastModified(),
                                    extension = ext
                                )
                            )
                        }
                    }
                }
            }

            for (dir in targetDirs) {
                scanDir(dir, 0)
            }

            results.distinctBy { it.path }.sortedByDescending { it.lastModified }
        }
        isLoading = false
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "گالری رسانه فایلکس",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "دسترسی سریع و هوشمند به فایل‌های تصویری، ویدیویی و صوتی",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Category Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedCategory == 0,
                    onClick = { selectedCategory = 0 },
                    label = { Text("تصاویر") },
                    leadingIcon = { Icon(Icons.Outlined.Image, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = selectedCategory == 1,
                    onClick = { selectedCategory = 1 },
                    label = { Text("ویدیوها") },
                    leadingIcon = { Icon(Icons.Outlined.Movie, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = selectedCategory == 2,
                    onClick = { selectedCategory = 2 },
                    label = { Text("صوت و موزیک") },
                    leadingIcon = { Icon(Icons.Outlined.Audiotrack, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "در حال پردازش رسانه‌ها...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else if (mediaFiles.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Outlined.Image,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "فایلی در این دسته‌بندی یافت نشد",
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(mediaFiles, key = { it.id }) { media ->
                        Surface(
                            onClick = { selectedMediaItem = media },
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(16.dp))
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                if (selectedCategory == 0 || selectedCategory == 1) {
                                    AsyncImage(
                                        model = media.path,
                                        contentDescription = media.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    if (selectedCategory == 1) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(Color.Black.copy(alpha = 0.35f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.Movie,
                                                contentDescription = "Video",
                                                tint = Color.White,
                                                modifier = Modifier.size(28.dp)
                                            )
                                        }
                                    }
                                } else {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Audiotrack,
                                            contentDescription = "Audio",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(32.dp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = media.name,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = FileFormatUtils.formatFileSize(media.size),
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Full Screen Media Viewer
        selectedMediaItem?.let { media ->
            MediaViewerDialog(
                fileItem = media,
                onDismiss = { selectedMediaItem = null }
            )
        }
    }
}
