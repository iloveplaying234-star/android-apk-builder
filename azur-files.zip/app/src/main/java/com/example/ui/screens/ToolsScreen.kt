package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.FormatConverterDialog
import com.example.ui.components.SizeReducerDialog
import com.example.viewmodel.MainViewModel

@Composable
fun ToolsScreen(
    viewModel: MainViewModel,
    onOpenSearch: () -> Unit,
    onNavigateToGallery: () -> Unit,
    onShowMessage: (String) -> Unit
) {
    var showFormatDialog by remember { mutableStateOf(false) }
    var showSizeReducerDialog by remember { mutableStateOf(false) }

    val fileList by viewModel.files.collectAsState()

    val toolList = remember {
        listOf(
            ToolItem("گالری رسانه", "تصاویر، ویدیوها و آواها", Icons.Outlined.PhotoLibrary, Color(0xFF3B82F6), "gallery"),
            ToolItem("تبدیل فرمت", "عکس، کد و متن", Icons.Outlined.Transform, Color(0xFF10B981), "convert"),
            ToolItem("کاهش حجم", "بهینه‌سازی تصاویر و فایل‌ها", Icons.Outlined.Compress, Color(0xFFF59E0B), "reduce"),
            ToolItem("جستجوی پیشرفته", "فیلتر دقیق و سریع", Icons.Outlined.Search, Color(0xFF8B5CF6), "search"),
            ToolItem("فشرده‌سازی فایل", "ایجاد فایل زیپ", Icons.Outlined.FolderZip, Color(0xFFEC4899), "zip"),
            ToolItem("ویرایشگر کد", "پشتیبانی از ۲۲ پسوند", Icons.Outlined.Code, Color(0xFF06B6D4), "editor")
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "ابزارهای کاربردی فایلکس",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "مجموعه ابزارهای قدرتمند مدیریت، ویرایش و تبدیل فایل",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 88.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(toolList) { tool ->
                    Surface(
                        onClick = {
                            when (tool.actionKey) {
                                "gallery" -> onNavigateToGallery()
                                "convert" -> showFormatDialog = true
                                "reduce" -> showSizeReducerDialog = true
                                "search" -> onOpenSearch()
                                "zip" -> {
                                    if (fileList.isNotEmpty()) {
                                        viewModel.compressFiles(fileList.map { it.path }, "Filex_Archive")
                                    } else {
                                        onShowMessage("هیچ فایلی در پوشه فعلی برای فشرده‌سازی وجود ندارد")
                                    }
                                }
                                "editor" -> onShowMessage("برای ویرایش کد، هر فایلی را از بخش فایل‌ها لمس کنید")
                                else -> onShowMessage("ابزار «${tool.title}» در فایلکس فعال است")
                            }
                        },
                        shape = RoundedCornerShape(22.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(tool.color.copy(alpha = 0.15f))
                            ) {
                                Icon(
                                    imageVector = tool.icon,
                                    contentDescription = tool.title,
                                    tint = tool.color,
                                    modifier = Modifier.size(26.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = tool.title,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = tool.subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Format Converter Dialog
        if (showFormatDialog) {
            FormatConverterDialog(
                selectedFileItem = fileList.firstOrNull { !it.isDirectory },
                allFiles = fileList,
                onDismiss = { showFormatDialog = false },
                onConverted = { _, msg ->
                    onShowMessage(msg)
                    viewModel.refreshAll()
                }
            )
        }

        // Size Reducer Dialog
        if (showSizeReducerDialog) {
            SizeReducerDialog(
                selectedFileItem = fileList.firstOrNull { !it.isDirectory },
                allFiles = fileList,
                onDismiss = { showSizeReducerDialog = false },
                onReduced = { _, msg ->
                    onShowMessage(msg)
                    viewModel.refreshAll()
                }
            )
        }
    }
}

private data class ToolItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: Color,
    val actionKey: String
)
