package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FileItem
import com.example.utils.FileFormatUtils
import com.example.utils.SyntaxHighlightUtils
import com.example.viewmodel.EditorViewModel

@Composable
fun EditorScreen(
    viewModel: EditorViewModel,
    isDarkTheme: Boolean,
    onNavigateBack: () -> Unit
) {
    val fileItem by viewModel.fileItem.collectAsState()
    val textContent by viewModel.textContent.collectAsState()
    val saveStatus by viewModel.saveStatus.collectAsState()
    val isMarkdownPreview by viewModel.isMarkdownPreview.collectAsState()

    val currentFile = fileItem ?: return
    val lines = remember(textContent.text) { textContent.text.split("\n") }
    val isMarkdown = currentFile.extension.equals("md", ignoreCase = true)

    Scaffold(
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .statusBarsPadding()
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = currentFile.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = currentFile.extension.uppercase(),
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.CheckCircle,
                                contentDescription = null,
                                tint = if (saveStatus.contains("خطا")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = saveStatus,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (isMarkdown) {
                        IconButton(onClick = { viewModel.toggleMarkdownPreview() }) {
                            Icon(
                                imageVector = if (isMarkdownPreview) Icons.Outlined.Edit else Icons.Outlined.Visibility,
                                contentDescription = "Preview",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    IconButton(onClick = { viewModel.saveFile() }) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = "Save", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        },
        bottomBar = {
            if (!isMarkdownPreview) {
                EditorShortcutBar(
                    onInsert = { prefix, suffix -> viewModel.insertTextAtSelection(prefix, suffix) },
                    onUndo = { viewModel.undo() },
                    onRedo = { viewModel.redo() }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(if (isDarkTheme) Color(0xFF0D0F14) else Color(0xFFFAFAFA))
        ) {
            if (isMarkdownPreview) {
                // Rendered Markdown Preview Screen
                MarkdownPreviewView(content = textContent.text, isDarkTheme = isDarkTheme)
            } else {
                // Code Editor with Line Numbers Gutter
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .imePadding()
                ) {
                    // Line Numbers Left Gutter
                    val verticalScrollState = rememberScrollState()

                    Column(
                        modifier = Modifier
                            .width(42.dp)
                            .fillMaxHeight()
                            .background(if (isDarkTheme) Color(0xFF14171E) else Color(0xFFF1F5F9))
                            .verticalScroll(verticalScrollState)
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        lines.indices.forEach { index ->
                            Text(
                                text = FileFormatUtils.toPersianDigits("${index + 1}"),
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                                color = if (isDarkTheme) Color(0xFF64748B) else Color(0xFF94A3B8),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.height(22.dp)
                            )
                        }
                    }

                    VerticalDivider(color = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFE2E8F0))

                    // Code Editor Text Field Area
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .horizontalScroll(rememberScrollState())
                            .verticalScroll(verticalScrollState)
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        OutlinedTextField(
                            value = textContent,
                            onValueChange = { viewModel.onContentChange(it) },
                            textStyle = LocalTextStyle.current.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 14.sp,
                                lineHeight = 22.sp,
                                color = if (isDarkTheme) Color(0xFFF8FAFC) else Color(0xFF0F172A)
                            ),
                            visualTransformation = VisualTransformation { text ->
                                val highlighted = SyntaxHighlightUtils.buildHighlightedText(
                                    text = text.text,
                                    extension = currentFile.extension,
                                    isDark = isDarkTheme
                                )
                                TransformedText(highlighted, OffsetMapping.Identity)
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent,
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EditorShortcutBar(
    onInsert: (prefix: String, suffix: String) -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier
            .fillMaxWidth()
            .imePadding()
    ) {
        Row(
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            IconButton(onClick = onUndo, modifier = Modifier.size(36.dp)) {
                Icon(imageVector = Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo", modifier = Modifier.size(18.dp))
            }
            IconButton(onClick = onRedo, modifier = Modifier.size(36.dp)) {
                Icon(imageVector = Icons.AutoMirrored.Filled.Redo, contentDescription = "Redo", modifier = Modifier.size(18.dp))
            }

            VerticalDivider(modifier = Modifier.height(20.dp))

            ShortcutChip(label = "Tab", onClick = { onInsert("  ", "") })
            ShortcutChip(label = "{ }", onClick = { onInsert("{ ", " }") })
            ShortcutChip(label = "[ ]", onClick = { onInsert("[ ", " ]") })
            ShortcutChip(label = "( )", onClick = { onInsert("( ", " )") })
            ShortcutChip(label = "\" \"", onClick = { onInsert("\"", "\"") })
            ShortcutChip(label = ":", onClick = { onInsert(": ", "") })
            ShortcutChip(label = "=", onClick = { onInsert(" = ", "") })
            ShortcutChip(label = "#", onClick = { onInsert("# ", "") })
            ShortcutChip(label = "**", onClick = { onInsert("**", "**") })
            ShortcutChip(label = "-", onClick = { onInsert("- ", "") })
        }
    }
}

@Composable
private fun ShortcutChip(label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.height(32.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 10.dp)
        ) {
            Text(
                text = label,
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun MarkdownPreviewView(content: String, isDarkTheme: Boolean) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        val paragraphs = content.split("\n")
        paragraphs.forEach { line ->
            when {
                line.startsWith("# ") -> {
                    Text(
                        text = line.removePrefix("# "),
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                line.startsWith("## ") -> {
                    Text(
                        text = line.removePrefix("## "),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                line.startsWith("### ") -> {
                    Text(
                        text = line.removePrefix("### "),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                line.startsWith("- ") || line.startsWith("* ") -> {
                    Row(verticalAlignment = Alignment.Top) {
                        Text(text = "• ", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                        Text(text = line.drop(2), style = MaterialTheme.typography.bodyMedium)
                    }
                }
                line.startsWith("---") -> {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                }
                else -> {
                    Text(text = line, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
