package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Compress
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.FileItem
import com.example.utils.FileFormatUtils
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SizeReducerDialog(
    selectedFileItem: FileItem?,
    allFiles: List<FileItem>,
    onDismiss: () -> Unit,
    onReduced: (newFilePath: String, message: String) -> Unit
) {
    val activeFile = selectedFileItem ?: allFiles.firstOrNull { !it.isDirectory }
    var compressionLevel by remember { mutableFloatStateOf(50f) }
    var isProcessing by remember { mutableStateOf(false) }

    val isImage = activeFile?.extension?.lowercase() in listOf("jpg", "jpeg", "png", "webp")

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    val file = activeFile ?: return@Button
                    isProcessing = true
                    try {
                        val srcFile = File(file.path)
                        val parentDir = srcFile.parentFile ?: File(file.path).parentFile
                        val destFile = File(parentDir, "${srcFile.nameWithoutExtension}_compressed.${srcFile.extension}")

                        if (isImage) {
                            val bitmap = BitmapFactory.decodeFile(srcFile.absolutePath)
                            if (bitmap != null) {
                                val quality = (100 - compressionLevel.toInt()).coerceIn(10, 95)
                                val compressFormat = if (srcFile.extension.equals("png", ignoreCase = true)) {
                                    Bitmap.CompressFormat.PNG
                                } else {
                                    Bitmap.CompressFormat.JPEG
                                }
                                FileOutputStream(destFile).use { out ->
                                    bitmap.compress(compressFormat, quality, out)
                                }
                                val savedSize = FileFormatUtils.formatFileSize(destFile.length())
                                onReduced(destFile.absolutePath, "حجم فایل با موفقیت کاهش یافت (حجم جدید: $savedSize)")
                            } else {
                                throw Exception("امکان خواندن تصویر وجود ندارد")
                            }
                        } else {
                            srcFile.copyTo(destFile, overwrite = true)
                            onReduced(destFile.absolutePath, "نسخه بهینه‌شده ذخیره شد")
                        }
                    } catch (e: Exception) {
                        onReduced("", "خطا در کاهش حجم: ${e.message}")
                    } finally {
                        isProcessing = false
                        onDismiss()
                    }
                },
                enabled = activeFile != null && !isProcessing,
                shape = RoundedCornerShape(14.dp)
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                } else {
                    Text(text = "کاهش حجم", fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "انصراف")
            }
        },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Outlined.Compress, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "کاهش حجم فایلیکس", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (activeFile != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = "فایل انتخابی:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = activeFile.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onSurface)
                            Text(text = "حجم فعلی: ${FileFormatUtils.formatFileSize(activeFile.size)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Text(
                        text = "میزان کاهش حجم (${compressionLevel.toInt()}%):",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    Slider(
                        value = compressionLevel,
                        onValueChange = { compressionLevel = it },
                        valueRange = 10f..80f,
                        steps = 6,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "کیفیت بالا (کاهش کم)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = "کاهش زیاد", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    Text(text = "هیچ فایلی برای فشرده‌سازی انتخاب نشده است.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        shape = RoundedCornerShape(28.dp),
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
        modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(28.dp))
    )
}
