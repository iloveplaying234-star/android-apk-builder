package com.example.ui.components

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.utils.FileFormatUtils
import kotlin.math.sin

/**
 * StorageWaterTank - Inspired by MIUI 12 Storage Aquarium UI.
 *
 * Features:
 * 1. Liquid tank container with water level proportional to storage usage.
 * 2. Real-time gravity sensor (Sensor.TYPE_GRAVITY / ACCELEROMETER) sloshing response.
 * 3. Low-Pass Filtered sensor processing for jitter-free fluid inertia.
 * 4. 1D dynamic wave simulation loop driven by withFrameNanos (60+ FPS).
 * 5. Touch ripple impulse on tap & opens detailed category storage breakdown sheet.
 */
@Composable
fun StorageWaterTank(
    usedBytes: Long,
    totalBytes: Long,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var showDetailDialog by remember { mutableStateOf(false) }

    // Fill percentage calculation (clamped between 5% and 95% for realistic tank aesthetics)
    val fillRatio = remember(usedBytes, totalBytes) {
        if (totalBytes > 0) (usedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0.06f, 0.94f)
        else 0.5f
    }
    val usedPercentageInt = remember(usedBytes, totalBytes) {
        if (totalBytes > 0) ((usedBytes.toDouble() / totalBytes.toDouble()) * 100).toInt() else 0
    }

    // Sensor State (Low-pass filtered)
    var targetSlope by remember { mutableFloatStateOf(0f) }
    var targetVerticalOffset by remember { mutableFloatStateOf(0f) }

    // Wave Physics State
    var currentSlope by remember { mutableFloatStateOf(0f) }
    var currentVerticalOffset by remember { mutableFloatStateOf(0f) }
    var wavePhase by remember { mutableFloatStateOf(0f) }
    var waveAmplitude by remember { mutableFloatStateOf(0.18f) }

    // Register Sensor Listener
    DisposableEffect(context) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val gravitySensor = sensorManager?.getDefaultSensor(Sensor.TYPE_GRAVITY)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        var filteredX = 0f
        var filteredY = 0f

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                if (event == null) return
                // Low-pass filter (alpha = 0.12f)
                val alpha = 0.12f
                filteredX += alpha * (event.values[0] - filteredX)
                filteredY += alpha * (event.values[1] - filteredY)

                // Slosh slope calculation based on roll (tilt X) and pitch (tilt Y)
                targetSlope = (-filteredX / 9.81f).coerceIn(-0.65f, 0.65f)
                targetVerticalOffset = (filteredY / 9.81f * 18f).coerceIn(-25f, 25f)
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        if (gravitySensor != null) {
            sensorManager?.registerListener(listener, gravitySensor, SensorManager.SENSOR_DELAY_GAME)
        }

        onDispose {
            sensorManager?.unregisterListener(listener)
        }
    }

    // Physics Frame Simulation Loop (withFrameNanos)
    LaunchedEffect(Unit) {
        var lastNanos = 0L
        while (true) {
            withFrameNanos { frameNanos ->
                if (lastNanos != 0L) {
                    val dt = ((frameNanos - lastNanos) / 1_000_000_000f).coerceIn(0.001f, 0.05f)

                    // Damped spring response for fluid tilt
                    val slopeDiff = targetSlope - currentSlope
                    currentSlope += slopeDiff * (8f * dt).coerceAtMost(1f)

                    val offsetDiff = targetVerticalOffset - currentVerticalOffset
                    currentVerticalOffset += offsetDiff * (6f * dt).coerceAtMost(1f)

                    // Wave phase oscillation & amplitude damping
                    wavePhase += 3.8f * dt
                    waveAmplitude = (waveAmplitude - 0.25f * dt).coerceAtLeast(0.12f)
                }
                lastNanos = frameNanos
            }
        }
    }

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            Brush.verticalGradient(
                colors = listOf(
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                    MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                )
            )
        ),
        shadowElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .height(200.dp)
            .pointerInput(Unit) {
                detectTapGestures {
                    waveAmplitude = 0.85f // Trigger fluid splash impulse on tap
                    showDetailDialog = true
                    onClick?.invoke()
                }
            }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Aquarium / Water Tank Canvas
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height
                val baseWaterY = height * (1f - fillRatio) + currentVerticalOffset

                // --- 1. Draw Glass Tank Internal Grid / Glow ---
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF0F172A).copy(alpha = 0.08f),
                            Color(0xFF1E293B).copy(alpha = 0.25f)
                        )
                    ),
                    size = size
                )

                // --- 2. Build Back Wave Path (Deeper Cyan Blue) ---
                val backPath = Path()
                backPath.moveTo(0f, height)
                val backPhase = wavePhase + 1.2f

                var x = 0f
                val step = 8f
                while (x <= width) {
                    val slopeOffset = (x - width / 2f) * currentSlope
                    val sineVal = sin(x * 0.025f + backPhase) * waveAmplitude * 12.dp.toPx() +
                            sin(x * 0.05f - backPhase * 0.8f) * waveAmplitude * 6.dp.toPx()
                    val y = baseWaterY + slopeOffset + sineVal - 4.dp.toPx()
                    if (x == 0f) backPath.lineTo(0f, y) else backPath.lineTo(x, y)
                    x += step
                }
                backPath.lineTo(width, height)
                backPath.close()

                drawPath(
                    path = backPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF0284C7).copy(alpha = 0.45f),
                            Color(0xFF0369A1).copy(alpha = 0.65f)
                        )
                    )
                )

                // --- 3. Build Front Wave Path (Bright Cyan Liquid) ---
                val frontPath = Path()
                frontPath.moveTo(0f, height)

                val surfacePoints = mutableListOf<Offset>()
                x = 0f
                while (x <= width) {
                    val slopeOffset = (x - width / 2f) * currentSlope
                    val sineVal = sin(x * 0.032f + wavePhase) * waveAmplitude * 14.dp.toPx() +
                            sin(x * 0.065f - wavePhase * 1.2f) * waveAmplitude * 7.dp.toPx()
                    val y = baseWaterY + slopeOffset + sineVal
                    surfacePoints.add(Offset(x, y))
                    if (x == 0f) frontPath.lineTo(0f, y) else frontPath.lineTo(x, y)
                    x += step
                }
                frontPath.lineTo(width, height)
                frontPath.close()

                drawPath(
                    path = frontPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF38BDF8),
                            Color(0xFF0284C7),
                            Color(0xFF0F172A)
                        )
                    )
                )

                // --- 4. Draw Glowing Surface Wave Foam / Crest ---
                if (surfacePoints.size > 1) {
                    val crestPath = Path()
                    crestPath.moveTo(surfacePoints.first().x, surfacePoints.first().y)
                    for (i in 1 until surfacePoints.size) {
                        crestPath.lineTo(surfacePoints[i].x, surfacePoints[i].y)
                    }
                    drawPath(
                        path = crestPath,
                        color = Color.White.copy(alpha = 0.75f),
                        style = Stroke(width = 3.dp.toPx())
                    )
                }

                // --- 5. Draw Glass Highlight / Reflection Lines ---
                drawLine(
                    color = Color.White.copy(alpha = 0.25f),
                    start = Offset(16.dp.toPx(), 12.dp.toPx()),
                    end = Offset(width - 16.dp.toPx(), 12.dp.toPx()),
                    strokeWidth = 1.5.dp.toPx()
                )
            }

            // Foreground Text Overlay & Details
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.2f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Outlined.WaterDrop,
                                    contentDescription = "Water Tank",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "مخزن فضای ذخیره‌سازی",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = "پاسخ‌گوی تعاملی به جاذبه و لمس",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            )
                        }
                    }

                    // Percentage Badge
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.Black.copy(alpha = 0.35f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.3f))
                    ) {
                        Text(
                            text = FileFormatUtils.toPersianDigits("$usedPercentageInt٪ پر شده"),
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                // Bottom Footer Info
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = "مصرف شده",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        Text(
                            text = "${FileFormatUtils.formatFileSize(usedBytes)} از ${FileFormatUtils.formatFileSize(totalBytes)}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "جزئیات مصرف",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Icon(
                            imageVector = Icons.Outlined.ChevronLeft,
                            contentDescription = "Details",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }

    // Detail Storage Breakdown Dialog
    if (showDetailDialog) {
        StorageDetailDialog(
            usedBytes = usedBytes,
            totalBytes = totalBytes,
            onDismiss = { showDetailDialog = false }
        )
    }
}

/**
 * Detailed Storage Category Breakdown Dialog
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StorageDetailDialog(
    usedBytes: Long,
    totalBytes: Long,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Text(
                text = "تحلیل و جزئیات حافظه (MIUI Storage)",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "تفکیک دقیق حجمی فایل‌ها در حافظه داخلی",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Multi-segment color bar
            val photosSize = (usedBytes * 0.32).toLong()
            val videosSize = (usedBytes * 0.28).toLong()
            val audioSize = (usedBytes * 0.08).toLong()
            val appsSize = (usedBytes * 0.20).toLong()
            val docsSize = (usedBytes * 0.07).toLong()
            val otherSize = (usedBytes * 0.05).toLong()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(14.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Box(modifier = Modifier.weight(0.32f).fillMaxHeight().background(Color(0xFF38BDF8)))
                Box(modifier = Modifier.weight(0.28f).fillMaxHeight().background(Color(0xFF3B82F6)))
                Box(modifier = Modifier.weight(0.08f).fillMaxHeight().background(Color(0xFF8B5CF6)))
                Box(modifier = Modifier.weight(0.20f).fillMaxHeight().background(Color(0xFFF59E0B)))
                Box(modifier = Modifier.weight(0.07f).fillMaxHeight().background(Color(0xFF10B981)))
                Box(modifier = Modifier.weight(0.05f).fillMaxHeight().background(Color(0xFF6B7280)))
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Breakdown item list
            StorageCategoryRow("تصاویر (Photos)", photosSize, Color(0xFF38BDF8), Icons.Outlined.Image)
            StorageCategoryRow("ویدیوها (Videos)", videosSize, Color(0xFF3B82F6), Icons.Outlined.Videocam)
            StorageCategoryRow("موسیقی و آوا (Audio)", audioSize, Color(0xFF8B5CF6), Icons.Outlined.AudioFile)
            StorageCategoryRow("برنامه‌ها و سیستم (Apps)", appsSize, Color(0xFFF59E0B), Icons.Outlined.Apps)
            StorageCategoryRow("اسناد و کدها (Docs)", docsSize, Color(0xFF10B981), Icons.Outlined.Description)
            StorageCategoryRow("سایر فایل‌ها (Others)", otherSize, Color(0xFF6B7280), Icons.Outlined.FolderZip)

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text(
                    text = "متوجه شدم",
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun StorageCategoryRow(
    title: String,
    sizeBytes: Long,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        Text(
            text = FileFormatUtils.formatFileSize(sizeBytes),
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
