package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.utils.FileFormatUtils

@Composable
fun PathBreadcrumb(
    currentPath: String,
    rootPath: String,
    onPathClick: (String) -> Unit
) {
    val scrollState = rememberScrollState()

    val segments = parsePathSegments(currentPath, rootPath)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Root Home Icon Chip
        Surface(
            onClick = { onPathClick(rootPath) },
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Outlined.Home,
                    contentDescription = "Root",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "حافظه داخلی",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        segments.forEach { segment ->
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(16.dp)
            )

            Surface(
                onClick = { onPathClick(segment.fullPath) },
                shape = RoundedCornerShape(12.dp),
                color = if (segment.fullPath == currentPath) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            ) {
                Text(
                    text = FileFormatUtils.toPersianDigits(segment.name),
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = if (segment.fullPath == currentPath) FontWeight.Bold else FontWeight.Normal
                    ),
                    color = if (segment.fullPath == currentPath) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
    }
}

private data class PathSegment(val name: String, val fullPath: String)

private fun parsePathSegments(currentPath: String, rootPath: String): List<PathSegment> {
    if (currentPath == rootPath || !currentPath.startsWith(rootPath)) return emptyList()

    val relative = currentPath.removePrefix(rootPath).trim('/')
    if (relative.isEmpty()) return emptyList()

    val parts = relative.split('/')
    val result = mutableListOf<PathSegment>()
    var accumulated = rootPath

    for (part in parts) {
        accumulated = "$accumulated/$part"
        result.add(PathSegment(part, accumulated))
    }

    return result
}
