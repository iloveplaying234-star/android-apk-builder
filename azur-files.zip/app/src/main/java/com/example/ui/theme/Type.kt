package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

val VazirmatnFontFamily = FontFamily(
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_regular, FontWeight.Light),
    Font(R.font.vazirmatn_regular, FontWeight.Thin),
    Font(R.font.vazirmatn_regular, FontWeight.W100),
    Font(R.font.vazirmatn_regular, FontWeight.W200),
    Font(R.font.vazirmatn_regular, FontWeight.W300),
    Font(R.font.vazirmatn_regular, FontWeight.W400),
    Font(R.font.vazirmatn_medium, FontWeight.Medium),
    Font(R.font.vazirmatn_medium, FontWeight.W500),
    Font(R.font.vazirmatn_semibold, FontWeight.SemiBold),
    Font(R.font.vazirmatn_semibold, FontWeight.W600),
    Font(R.font.vazirmatn_bold, FontWeight.Bold),
    Font(R.font.vazirmatn_bold, FontWeight.W700),
    Font(R.font.vazirmatn_bold, FontWeight.ExtraBold),
    Font(R.font.vazirmatn_bold, FontWeight.W800),
    Font(R.font.vazirmatn_bold, FontWeight.Black),
    Font(R.font.vazirmatn_bold, FontWeight.W900)
)

val InterFontFamily = FontFamily(
    Font(R.font.inter, FontWeight.Normal),
    Font(R.font.inter, FontWeight.Medium),
    Font(R.font.inter, FontWeight.SemiBold),
    Font(R.font.inter, FontWeight.Bold),
    Font(R.font.inter, FontWeight.ExtraBold),
    Font(R.font.inter, FontWeight.W100),
    Font(R.font.inter, FontWeight.W200),
    Font(R.font.inter, FontWeight.W300),
    Font(R.font.inter, FontWeight.W400),
    Font(R.font.inter, FontWeight.W500),
    Font(R.font.inter, FontWeight.W600),
    Font(R.font.inter, FontWeight.W700),
    Font(R.font.inter, FontWeight.W800),
    Font(R.font.inter, FontWeight.W900)
)

private val defaultTypography = Typography()

val Typography = Typography(
    displayLarge = defaultTypography.displayLarge.copy(fontFamily = VazirmatnFontFamily),
    displayMedium = defaultTypography.displayMedium.copy(fontFamily = VazirmatnFontFamily),
    displaySmall = defaultTypography.displaySmall.copy(fontFamily = VazirmatnFontFamily),
    headlineLarge = defaultTypography.headlineLarge.copy(fontFamily = VazirmatnFontFamily),
    headlineMedium = defaultTypography.headlineMedium.copy(fontFamily = VazirmatnFontFamily),
    headlineSmall = defaultTypography.headlineSmall.copy(fontFamily = VazirmatnFontFamily),
    titleLarge = defaultTypography.titleLarge.copy(fontFamily = VazirmatnFontFamily),
    titleMedium = defaultTypography.titleMedium.copy(fontFamily = VazirmatnFontFamily),
    titleSmall = defaultTypography.titleSmall.copy(fontFamily = VazirmatnFontFamily),
    bodyLarge = defaultTypography.bodyLarge.copy(fontFamily = VazirmatnFontFamily),
    bodyMedium = defaultTypography.bodyMedium.copy(fontFamily = VazirmatnFontFamily),
    bodySmall = defaultTypography.bodySmall.copy(fontFamily = VazirmatnFontFamily),
    labelLarge = defaultTypography.labelLarge.copy(fontFamily = VazirmatnFontFamily),
    labelMedium = defaultTypography.labelMedium.copy(fontFamily = VazirmatnFontFamily),
    labelSmall = defaultTypography.labelSmall.copy(fontFamily = VazirmatnFontFamily)
)

