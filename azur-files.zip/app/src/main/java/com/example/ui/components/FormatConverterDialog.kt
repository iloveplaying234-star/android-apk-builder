package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Transform
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.FileItem
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormatConverterDialog(
    selectedFileItem: FileItem?,
    allFiles: List<FileItem>,
    onDismiss: () -> Unit,
    onConverted: (newFilePath: String, message: String) -> Unit
) {
    val context = LocalContext.current
    var activeFile by remember { mutableStateOf(selectedFileItem ?: allFiles.firstOrNull { !it.isDirectory }) }
    var targetFormat by remember { mutableStateOf("png") }
    var isProcessing by remember { mutableStateOf(false) }

    val isImage = activeFile?.extension?.lowercase() in listOf("jpg", "jpeg", "png", "webp", "bmp")
    val isText = activeFile?.extension?.lowercase() in listOf("txt", "md", "json", "xml", "yaml", "html", "csv")

    val availableFormats = when {
        isImage -> listOf("png", "jpg", "webp")
        isText -> when (activeFile?.extension?.lowercase()) {
            "md" -> listOf("html", "txt")
            "json" -> listOf("xml", "yaml", "txt")
            "csv" -> listOf("json", "txt")
            else -> listOf("txt", "md")
        }
        else -> listOf("zip", "txt")
    }

    LaunchedEffect(activeFile) {
        if (availableFormats.isNotEmpty()) {
            targetFormat = availableFormats.first()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    val file = activeFile ?: return@Button
                    isProcessing = true
                    try {
                        val srcFile = File(file.path)
                        val parentDir = srcFile.parentFile ?: File(file.path).parentFile
                        val baseName = srcFile.nameWithoutExtension
                        val destFile = File(parentDir, "${baseName}_converted.$targetFormat")

                        if (isImage) {
                            val bitmap = BitmapFactory.decodeFile(srcFile.absolutePath)
                            if (bitmap != null) {
                                val compressFormat = when (targetFormat.lowercase()) {
                                    "png" -> Bitmap.CompressFormat.PNG
                                    "webp" -> Bitmap.CompressFormat.WEBP
                                    else -> Bitmap.CompressFormat.JPEG
                                }
                                FileOutputStream(destFile).use { out ->
                                    bitmap.compress(compressFormat, 90, out)
                                }
                                onConverted(destFile.absolutePath, "تصویر با موفقیت به $targetFormat تبدیل شد")
                            } else {
                                throw Exception("امکان خواندن تصویر وجود ندارد")
                            }
                        } else if (isText) {
                            val content = srcFile.readText(Charsets.UTF_8)
                            val convertedContent = when (targetFormat.lowercase()) {
                                "html" -> "<!DOCTYPE html>\n<html>\n<body>\n<pre>\n$content\n</pre>\n</body>\n</html>"
                                "xml" -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<converted>\n<content>$content</content>\n</converted>"
                                "yaml" -> "converted:\n  text: |-\n    ${content.replace("\n", "\n    ")}"
                                else -> content
                            }
                            destFile.writeText(convertedContent, Charsets.UTF_8)
                            onConverted(destFile.absolutePath, "فایل با موفقیت به فرمت $targetFormat تبدیل شد")
                        } else {
                            srcFile.copyTo(destFile, overwrite = true)
                            onConverted(destFile.absolutePath, "کپی فرمت انجام شد")
                        }
                    } catch (e: Exception) {
                        onConverted("", "خطا در تبدیل: ${e.message}")
                    } finally {
                        isProcessing = false
                        onDismiss()
                    }
                },
                enabled = activeFile != null && !isProcessing,
                shape = RoundedCornerShape(14.dp)
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                } else {
                    Text(text = "تبدیل فرمت", fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "انصراف")
            }
        },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Outlined.Transform, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "مبدل فرمت فایلکس", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (activeFile != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = "فایل انتخابی:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = activeFile!!.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onSurface)
                        }
                    }

                    Text(text = "فرمت مقصد را انتخاب کنید:", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        availableFormats.forEach { fmt ->
                            val selected = targetFormat == fmt
                            Surface(
                                onClick = { targetFormat = fmt },
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(text = ".$fmt", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    Text(text = "هیچ فایلی برای تبدیل انتخاب نشده است.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        shape = RoundedCornerShape(28.dp),
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
        modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(28.dp))
    )
}
