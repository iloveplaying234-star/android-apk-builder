package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.FileItem
import com.example.model.ViewMode
import com.example.ui.components.FileDetailBottomSheet
import com.example.ui.components.FileItemCard
import com.example.ui.components.FileItemRow
import com.example.ui.components.PathBreadcrumb
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun FilesScreen(
    viewModel: MainViewModel,
    onOpenFileInEditor: (FileItem) -> Unit,
    onShareFile: (FileItem) -> Unit,
    onOpenRenameDialog: (FileItem) -> Unit
) {
    val currentPath by viewModel.currentPath.collectAsState()
    val files by viewModel.files.collectAsState()
    val viewMode by viewModel.viewMode.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val rootPath = viewModel.repositoryManager.getRootPath()

    var activeSelectedItem by remember { mutableStateOf<FileItem?>(null) }
    var mediaViewerItem by remember { mutableStateOf<FileItem?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Path Breadcrumb Navigation
        PathBreadcrumb(
            currentPath = currentPath,
            rootPath = rootPath,
            onPathClick = { target -> viewModel.navigateToDirectory(target) }
        )

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

        AnimatedContent(
            targetState = currentPath to files,
            transitionSpec = {
                (fadeIn(animationSpec = tween(220, easing = FastOutSlowInEasing)) +
                        scaleIn(initialScale = 0.96f, animationSpec = tween(220)))
                    .togetherWith(
                        fadeOut(animationSpec = tween(180, easing = FastOutSlowInEasing)) +
                                scaleOut(targetScale = 1.02f, animationSpec = tween(180))
                    )
            },
            label = "file_navigation_transition"
        ) { (_, fileList) ->
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (fileList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Outlined.FolderOpen,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "این پوشه خالی است",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "برای افزودن فایل از دکمه + پایین استفاده کنید",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                }
            } else {
                if (viewMode == ViewMode.LIST) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp)
                    ) {
                        items(fileList, key = { it.id }) { item ->
                            val onItemClick = {
                                val isMedia = item.extension.lowercase() in listOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "mp4", "mkv", "webm", "avi", "mp3", "wav", "aac", "flac", "m4a", "ogg")
                                if (item.isDirectory) {
                                    viewModel.navigateToDirectory(item.path)
                                } else if (isMedia) {
                                    viewModel.addToRecent(item)
                                    mediaViewerItem = item
                                } else if (item.isTextOrCodeFile) {
                                    viewModel.addToRecent(item)
                                    onOpenFileInEditor(item)
                                } else {
                                    activeSelectedItem = item
                                }
                            }

                            FileItemRow(
                                item = item,
                                onClick = onItemClick,
                                onFavoriteToggle = { viewModel.toggleFavorite(item.path) },
                                onMenuClick = { activeSelectedItem = item }
                            )
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(10.dp, bottom = 80.dp)
                    ) {
                        items(fileList, key = { it.id }) { item ->
                            val onItemClick = {
                                val isMedia = item.extension.lowercase() in listOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "mp4", "mkv", "webm", "avi", "mp3", "wav", "aac", "flac", "m4a", "ogg")
                                if (item.isDirectory) {
                                    viewModel.navigateToDirectory(item.path)
                                } else if (isMedia) {
                                    viewModel.addToRecent(item)
                                    mediaViewerItem = item
                                } else if (item.isTextOrCodeFile) {
                                    viewModel.addToRecent(item)
                                    onOpenFileInEditor(item)
                                } else {
                                    activeSelectedItem = item
                                }
                            }

                            FileItemCard(
                                item = item,
                                onClick = onItemClick,
                                onMenuClick = { activeSelectedItem = item }
                            )
                        }
                    }
                }
            }
        }
    }

    // Media Viewer Dialog
    mediaViewerItem?.let { media ->
        com.example.ui.components.MediaViewerDialog(
            fileItem = media,
            onDismiss = { mediaViewerItem = null }
        )
    }

    // Detail Bottom Sheet
    activeSelectedItem?.let { item ->
        FileDetailBottomSheet(
            item = item,
            onDismiss = { activeSelectedItem = null },
            onOpen = {
                if (item.isDirectory) {
                    viewModel.navigateToDirectory(item.path)
                } else {
                    onOpenFileInEditor(item)
                }
            },
            onShare = { onShareFile(item) },
            onRename = { onOpenRenameDialog(item) },
            onDelete = { viewModel.deleteFile(item.path) },
            onCompressZip = {
                viewModel.compressFiles(listOf(item.path), "${item.name}_archived")
            },
            onExtractZip = {
                viewModel.extractZip(item.path)
            }
        )
    }
}
