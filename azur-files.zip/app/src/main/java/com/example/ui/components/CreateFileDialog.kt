package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateFileDialog(
    onDismiss: () -> Unit,
    onCreateFile: (fileName: String, templateContent: String) -> Unit,
    onCreateFolder: (folderName: String) -> Unit
) {
    var isFolderMode by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf("") }
    var selectedExt by remember { mutableStateOf("kt") }

    val formatList = remember {
        listOf(
            "kt", "py", "js", "ts", "html", "css",
            "json", "xml", "md", "txt", "sh", "sql",
            "yaml", "csv", "c", "cpp", "java", "go",
            "php", "rs", "conf", "log"
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    if (nameInput.isNotBlank()) {
                        if (isFolderMode) {
                            onCreateFolder(nameInput.trim())
                        } else {
                            val cleanName = nameInput.trim()
                            val finalName = if (cleanName.contains(".")) cleanName else "$cleanName.$selectedExt"
                            val ext = if (cleanName.contains(".")) cleanName.substringAfterLast(".") else selectedExt
                            val template = getTemplateContent(ext)
                            onCreateFile(finalName, template)
                        }
                        onDismiss()
                    }
                },
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(text = "ایجاد", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "انصراف")
            }
        },
        title = {
            Text(
                text = if (isFolderMode) "ایجاد پوشه جدید" else "ایجاد فایل جدید",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Segment Switcher
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .padding(4.dp)
                ) {
                    Surface(
                        onClick = { isFolderMode = false },
                        shape = RoundedCornerShape(12.dp),
                        color = if (!isFolderMode) MaterialTheme.colorScheme.primary else Color.Transparent,
                        contentColor = if (!isFolderMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(imageVector = Icons.Outlined.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "فایل / کد", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }

                    Surface(
                        onClick = { isFolderMode = true },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isFolderMode) MaterialTheme.colorScheme.primary else Color.Transparent,
                        contentColor = if (isFolderMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(imageVector = Icons.Outlined.Folder, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "پوشه جدید", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }

                // Name Input
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text(if (isFolderMode) "نام پوشه" else "نام فایل") },
                    placeholder = { Text(if (isFolderMode) "مثلاً: Projects" else "مثلاً: AppController") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (!isFolderMode) {
                    Text(
                        text = "انتخاب پسوند و فرمت کد:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(formatList) { ext ->
                            val isSelected = selectedExt == ext
                            Surface(
                                onClick = { selectedExt = ext },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null,
                                modifier = Modifier.height(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = ".$ext",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        shape = RoundedCornerShape(28.dp),
        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
        modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(28.dp))
    )
}

private fun getTemplateContent(ext: String): String {
    return when (ext.lowercase()) {
        "kt" -> """// Filex Kotlin Source File
package com.example

fun main() {
    println("سلام از فایلکس!")
}
"""
        "py" -> """# Filex Python Script
def main():
    print("سلام از فایلکس!")

if __name__ == "__main__":
    main()
"""
        "js" -> """// Filex JavaScript Module
function helloFilex() {
    console.log("سلام از فایلکس!");
}

helloFilex();
"""
        "ts" -> """// Filex TypeScript Module
interface User {
    id: number;
    name: string;
}

const user: User = { id: 1, name: "Filex User" };
console.log(user);
"""
        "html" -> """<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>صفحه جدید فایلکس</title>
</head>
<body>
    <h1>به فایلکس خوش آمدید</h1>
</body>
</html>
"""
        "css" -> """/* Filex Stylesheet */
body {
    background-color: #0A0A0A;
    color: #F8FAFC;
    font-family: 'Vazirmatn', sans-serif;
}
"""
        "json" -> """{
  "appName": "Filex",
  "version": "1.0.0",
  "status": "active"
}
"""
        "xml" -> """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="welcome">به فایلکس خوش آمدید</string>
</resources>
"""
        "md" -> """# عنوان فایل جدید

این یک سند مارک‌داون جدید در **فایلکس** است.

- پشتیبانی کامل از تیترها
- جدول و کد
- پیش‌نمایش زنده
"""
        "sh" -> """#!/bin/bash
# Filex Shell Script
echo "اجرای اسکریپت فایلکس..."
"""
        "sql" -> """-- Filex SQL Script
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""
        "yaml" -> """# Filex Configuration
app:
  name: Filex
  env: production
"""
        "csv" -> """شناسه,نام,تاریخ
1,فایل اول,1405/01/01
2,فایل دوم,1405/01/02
"""
        "c" -> """// Filex C Source
#include <stdio.h>

int main() {
    printf("سلام از فایلکس!\n");
    return 0;
}
"""
        "cpp" -> """// Filex C++ Source
#include <iostream>

int main() {
    std::cout << "سلام از فایلکس!" << std::endl;
    return 0;
}
"""
        "java" -> """// Filex Java Source
public class Main {
    public static void main(String[] args) {
        System.out.println("سلام از فایلکس!");
    }
}
"""
        "go" -> """// Filex Go Source
package main

import "fmt"

func main() {
    fmt.Println("سلام از فایلکس!")
}
"""
        "rs" -> """// Filex Rust Source
fn main() {
    println!("سلام از فایلکس!");
}
"""
        "php" -> """<?php
// Filex PHP Script
echo "سلام از فایلکس!";
?>
"""
        else -> "این یک فایل متنی جدید در فایلکس است.\n"
    }
}
