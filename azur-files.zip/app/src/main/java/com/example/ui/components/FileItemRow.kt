package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FileItem
import com.example.utils.FileFormatUtils

@Composable
fun FileItemRow(
    item: FileItem,
    onClick: () -> Unit,
    onFavoriteToggle: () -> Unit,
    onMenuClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // File / Folder Icon Box
            FileIconBadge(item = item)

            Spacer(modifier = Modifier.width(12.dp))

            // Details Column
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val subtitle = if (item.isDirectory) {
                        FileFormatUtils.toPersianDigits("${item.itemCount} مورد")
                    } else {
                        FileFormatUtils.formatFileSize(item.size)
                    }
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = " • ",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = FileFormatUtils.getRelativeTimeString(item.lastModified),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Favorite Icon
            IconButton(
                onClick = onFavoriteToggle,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (item.isFavorite) Icons.Default.Star else Icons.Outlined.StarBorder,
                    contentDescription = "Favorite",
                    tint = if (item.isFavorite) Color(0xFFF59E0B) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(20.dp)
                )
            }

            // More Options
            IconButton(
                onClick = onMenuClick,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Options",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun FileItemCard(
    item: FileItem,
    onClick: () -> Unit,
    onMenuClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .padding(6.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FileIconBadge(item = item)
                IconButton(
                    onClick = onMenuClick,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "More",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = item.name,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            val subtitle = if (item.isDirectory) {
                FileFormatUtils.toPersianDigits("${item.itemCount} مورد")
            } else {
                FileFormatUtils.formatFileSize(item.size)
            }
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun FileIconBadge(item: FileItem) {
    val (icon, bgColor, tintColor) = getIconAndColors(item)

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(bgColor)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = item.extension,
            tint = tintColor,
            modifier = Modifier.size(24.dp)
        )
    }
}

private fun getIconAndColors(item: FileItem): Triple<ImageVector, Color, Color> {
    if (item.isDirectory) {
        return Triple(
            Icons.Outlined.Folder,
            Color(0xFF3B82F6).copy(alpha = 0.15f),
            Color(0xFF3B82F6)
        )
    }

    return when (item.extension.lowercase()) {
        "json" -> Triple(
            Icons.Outlined.Code,
            Color(0xFF06B6D4).copy(alpha = 0.15f),
            Color(0xFF06B6D4)
        )
        "md", "markdown" -> Triple(
            Icons.Outlined.Description,
            Color(0xFF10B981).copy(alpha = 0.15f),
            Color(0xFF10B981)
        )
        "txt" -> Triple(
            Icons.Outlined.Article,
            Color(0xFF64748B).copy(alpha = 0.15f),
            Color(0xFF64748B)
        )
        "jpg", "jpeg", "png", "webp" -> Triple(
            Icons.Outlined.Image,
            Color(0xFFEC4899).copy(alpha = 0.15f),
            Color(0xFFEC4899)
        )
        "zip", "rar", "7z" -> Triple(
            Icons.Outlined.FolderZip,
            Color(0xFFA855F7).copy(alpha = 0.15f),
            Color(0xFFA855F7)
        )
        "apk" -> Triple(
            Icons.Outlined.Android,
            Color(0xFF22C55E).copy(alpha = 0.15f),
            Color(0xFF22C55E)
        )
        else -> Triple(
            Icons.Outlined.InsertDriveFile,
            Color(0xFF3B82F6).copy(alpha = 0.12f),
            Color(0xFF3B82F6)
        )
    }
}
