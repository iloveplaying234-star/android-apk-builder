package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Theme Colors
val DarkBackground = Color(0xFF0A0A0A)
val DarkSurface = Color(0xFF16181D)
val DarkSurfaceVariant = Color(0xFF22252D)
val DarkBorder = Color(0xFF2A2E37)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)

// Brand Accents
val AzurBluePrimary = Color(0xFF3B82F6)      // Soft Blue Glow
val AzurBlueSecondary = Color(0xFF2563EB)    // Deep Soft Blue
val AzurCyan = Color(0xFF06B6D4)             // Cyan Highlight
val AzurEmerald = Color(0xFF10B981)          // Emerald Green
val AzurAmber = Color(0xFFF59E0B)            // Amber Warning
val AzurRose = Color(0xFFF43F5E)             // Rose Error

val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)
