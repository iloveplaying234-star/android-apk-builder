package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FileItem
import com.example.model.StorageInfo
import com.example.ui.components.FileItemRow
import com.example.utils.FileFormatUtils
import com.example.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToFiles: (path: String) -> Unit,
    onOpenFileInEditor: (item: FileItem) -> Unit,
    onOpenSearch: () -> Unit
) {
    val storageInfo by viewModel.storageInfo.collectAsState()
    val categoryCounts by viewModel.categoryCounts.collectAsState()
    val recentFiles by viewModel.recentFiles.collectAsState()
    val rootPath = viewModel.repositoryManager.getRootPath()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Top Welcome Banner
        item {
            Column(modifier = Modifier.padding(top = 8.dp)) {
                Text(
                    text = "سلام، خوش آمدید",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, fontSize = 22.sp),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "مدیریت فایل فایلکس • حافظه داخلی دستگاه",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Search Bar Trigger
        item {
            Surface(
                onClick = onOpenSearch,
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = "Search",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "جستجو در فایل‌ها و پوشه‌ها...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // MIUI 12 Storage Water Tank
        item {
            com.example.ui.components.StorageWaterTank(
                usedBytes = storageInfo.usedBytes,
                totalBytes = storageInfo.totalBytes,
                onClick = { onNavigateToFiles(rootPath) }
            )
        }

        // Quick Categories Grid
        item {
            Text(
                text = "پوشه‌های محبوب",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CategoryCard(
                        title = "دانلودها",
                        subtitle = FileFormatUtils.toPersianDigits("${categoryCounts.downloadsCount} مورد"),
                        icon = Icons.Outlined.Download,
                        bgColor = Color(0xFF10B981).copy(alpha = 0.15f),
                        iconColor = Color(0xFF10B981),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val dir = java.io.File(rootPath, "Download")
                            if (!dir.exists()) dir.mkdirs()
                            onNavigateToFiles(dir.absolutePath)
                        }
                    )
                    CategoryCard(
                        title = "پروژه‌ها",
                        subtitle = FileFormatUtils.toPersianDigits("${categoryCounts.projectsCount} مورد"),
                        icon = Icons.Outlined.FolderSpecial,
                        bgColor = Color(0xFFF59E0B).copy(alpha = 0.15f),
                        iconColor = Color(0xFFF59E0B),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val dir = java.io.File(rootPath, "Projects")
                            if (!dir.exists()) dir.mkdirs()
                            onNavigateToFiles(dir.absolutePath)
                        }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CategoryCard(
                        title = "عکس‌ها",
                        subtitle = FileFormatUtils.toPersianDigits("${categoryCounts.picturesCount} مورد"),
                        icon = Icons.Outlined.Image,
                        bgColor = Color(0xFFEC4899).copy(alpha = 0.15f),
                        iconColor = Color(0xFFEC4899),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val dir = java.io.File(rootPath, "Pictures")
                            if (!dir.exists()) dir.mkdirs()
                            onNavigateToFiles(dir.absolutePath)
                        }
                    )
                    CategoryCard(
                        title = "مستندات",
                        subtitle = FileFormatUtils.toPersianDigits("${categoryCounts.documentsCount} مورد"),
                        icon = Icons.Outlined.Description,
                        bgColor = Color(0xFF06B6D4).copy(alpha = 0.15f),
                        iconColor = Color(0xFF06B6D4),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val dir = java.io.File(rootPath, "Documents")
                            if (!dir.exists()) dir.mkdirs()
                            onNavigateToFiles(dir.absolutePath)
                        }
                    )
                }
            }
        }

        // Recent Files Section
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "اخيراً استفاده شده",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                TextButton(onClick = { onNavigateToFiles(rootPath) }) {
                    Text(text = "مشاهده همه")
                }
            }
        }

        if (recentFiles.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .padding(24.dp)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Outlined.History,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "هنوز فایلی باز نشده است",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        } else {
            items(recentFiles) { item ->
                FileItemRow(
                    item = item,
                    onClick = {
                        if (item.isTextOrCodeFile) {
                            onOpenFileInEditor(item)
                        } else if (item.isDirectory) {
                            onNavigateToFiles(item.path)
                        }
                    },
                    onFavoriteToggle = { viewModel.toggleFavorite(item.path) },
                    onMenuClick = {}
                )
            }
        }
    }
}

@Composable
private fun StorageCard(storageInfo: StorageInfo, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Storage,
                            contentDescription = "Storage",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "حافظه داخلی",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${FileFormatUtils.formatFileSize(storageInfo.usedBytes)} از ${FileFormatUtils.formatFileSize(storageInfo.totalBytes)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Text(
                    text = FileFormatUtils.toPersianDigits("${(storageInfo.usedPercentage * 100).toInt()}%"),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Progress Bar
            LinearProgressIndicator(
                progress = { storageInfo.usedPercentage },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(CircleShape),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}

@Composable
private fun CategoryCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    bgColor: Color,
    iconColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(bgColor)
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = iconColor, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
